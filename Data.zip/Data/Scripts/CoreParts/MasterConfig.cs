namespace Scripts
{
    partial class Parts
    {
        internal Parts()
        {
            // naming convention: WeaponDefinition Name
            //
            // Enable your definitions using the follow syntax:
            // PartDefinitions(Your1stDefinition, Your2ndDefinition, Your3rdDefinition);
            // PartDefinitions includes both weapons and phantoms
            PartDefinitions(odin_def, nariman_def, hermesRail1_def, stallionRail_def, avengerGatling_def, twinrail_def, thor_01_def, shipthor_01_def, ragnarok_01_def, lokiCannon1_def, hugin_launcher_01def, ymir_launcher_01def, ymir_launcher_02def, mjolnir_launcher_01def, nariman_compact_def, honir_designator_01_def, jotnar_launcher_01def);
            ArmorDefinitions();
            SupportDefinitions();
            UpgradeDefinitions();
        }
    }
}